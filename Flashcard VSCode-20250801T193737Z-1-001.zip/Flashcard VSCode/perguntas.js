criaCartao(
    'Programação',
    'O que é Python?',
    'O Python é uma linguagem de programação'
)

criaCartao(
    'Geografia',
    'Em qual continente está localizada a Jamaica?',
    'No continente americano, especificamente na América Central, na região do Caribe'
)

criaCartao(
    'Programação',
    'O que é CSS?',
    'CSS é uma linguagem de estilização'
)

criaCartao(
    'Química',
    'Atualmente, quantos elementos químicos a tabela periódica possui?',
    '118'
)

criaCartao(
    'Programação',
    'O que é uma GitHub?',
    'O GitHub é uma plataforma de hospedagem de códigos'
)

criaCartao(
    'Inglês',
    'Como se soletra "borboleta" em inglês?',
    'B-U-T-T-E-R-F-L-Y'
)

criaCartao(
    'Artes',
    'Quem pintou "Guernica"?',
    'Pablo Picasso'
)

criaCartao(
    'Programação',
    'O que é p5.js?',
    'p5.js é uma biblioteca JavaScript de código aberto'
)

criaCartao(
    'História',
    'Qual golpe colocou D. Pedro II no poder do Brasil, e com qual idade ele ascendeu ao trono?',
    '"Golpe da Maioridade", aos 14 anos de idade.'
)